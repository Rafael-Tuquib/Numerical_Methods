function data = BisectionMethod(f, xl, xu, tol)

i = 1;
xr_old = 0;
data = {};

while true

    xr = (xl + xu) / 2;

    fxl = f(xl);
    fxr = f(xr);

    product = fxl * fxr;

    if i == 1
        ea = 0;
    else
        ea = abs((xr - xr_old) / xr) * 100;
    end

    remarks = '';

    if product < 0
        remarks = 'Replace XU';
        xu = xr;
    else
        remarks = 'Replace XL';
        xl = xr;
    end

    if ea < tol && i > 1
        remarks = 'Converged';
    end

    data(end+1,:) = ...
    {i, xl, xr, xu, fxl, fxr, ea, product, remarks};

    if ea < tol && i > 1
        break;
    end

    xr_old = xr;
    i = i + 1;

    if i > 100
        break;
    end
end
end