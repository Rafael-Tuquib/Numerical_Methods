classdef numericalmethod < matlab.apps.AppBase

    properties (Access = public)
        UIFigure matlab.ui.Figure
        TabGroup matlab.ui.container.TabGroup
        RootTab matlab.ui.container.Tab
        MatrixTab matlab.ui.container.Tab

        % Root Finding UI
        UITable matlab.ui.control.Table
        UIAxes matlab.ui.control.UIAxes
        MethodDropDown matlab.ui.control.DropDown
        EquationDropDown matlab.ui.control.DropDown
        CustomEquationField matlab.ui.control.EditField
        XLEdit matlab.ui.control.NumericEditField
        XUEdit matlab.ui.control.NumericEditField
        ToleranceEdit matlab.ui.control.NumericEditField
        ComputeButton matlab.ui.control.Button

        % Matrix UI
        MatrixInput matlab.ui.control.TextArea
        MatrixOutput matlab.ui.control.TextArea
        MatrixOpDropDown matlab.ui.control.DropDown
        MatrixButton matlab.ui.control.Button
        MatrixBInput matlab.ui.control.TextArea
    end

    methods (Access = private)

        %% ================= ROOT METHODS =================
        function [f, df] = GetEquation(app)
            % Get selected equation
            eqType = app.EquationDropDown.Value;
            
            switch eqType
                case 'x^3 - x - 2'
                    f = @(x) x.^3 - x - 2;
                    df = @(x) 3*x.^2 - 1;
                    
                case 'sin(x) - 0.5'
                    f = @(x) sin(x) - 0.5;
                    df = @(x) cos(x);
                    
                case 'exp(x) - 3'
                    f = @(x) exp(x) - 3;
                    df = @(x) exp(x);
                    
                case 'x^2 - 4'
                    f = @(x) x.^2 - 4;
                    df = @(x) 2*x;
                    
                case 'cos(x) - x'
                    f = @(x) cos(x) - x;
                    df = @(x) -sin(x) - 1;
                    
                case 'log(x) - 1'
                    f = @(x) log(x) - 1;
                    df = @(x) 1./x;
                    
                case 'Custom'
                    % Parse custom equation
                    eqStr = app.CustomEquationField.Value;
                    if isempty(eqStr)
                        uialert(app.UIFigure, 'Please enter a custom equation', 'Error');
                        f = [];
                        df = [];
                        return;
                    end
                    
                    try
                        % Create function from string
                        f = eval(['@(x) ' eqStr]);
                        % Numerical derivative approximation
                        A = eval(char(strjoin(app.MatrixInput.Value))); %#ok<NASGU>              
                    catch
                        uialert(app.UIFigure, 'Invalid custom equation. Use valid MATLAB syntax (e.g., x^2 - 4)', 'Error');
                        f = [];
                        df = [];
                        return;
                    end
                    
                otherwise
                    f = [];
                    df = [];
            end
        end

        function ComputeRoot(app)

    [f, df] = GetEquation(app);
    if isempty(f)
        return;
    end

    xl = app.XLEdit.Value;
    xu = app.XUEdit.Value;
    tol = app.ToleranceEdit.Value;

    method = app.MethodDropDown.Value;

    switch method

        case 'Bisection'
            data = BisectionMethod(f, xl, xu, tol);

        case 'Regula Falsi'
            data = RegulaFalsiMethod(f, xl, xu, tol);

        case 'Secant'
            data = SecantMethod(f, xl, xu, tol);

        case 'Newton Raphson'
            data = NewtonMethod(f, df, xl, tol);

        case 'Incremental'
            data = IncrementalMethod(f, xl, tol);
    end

    % Display table
    app.UITable.Data = data;
    app.UITable.ColumnName = ...
        {'i','XL','XR','XU','f(XL)','f(XR)','Ea','Product','Remarks'};

    % Plot
    x = linspace(-10, 10, 500);
    y = f(x);

    plot(app.UIAxes, x, y, 'LineWidth', 2);
    hold(app.UIAxes, 'on');
    yline(app.UIAxes, 0, '--r');
    grid(app.UIAxes, 'on');

    % Optional: mark root (last XR)
    lastXR = data{end,3};
    plot(app.UIAxes, lastXR, f(lastXR), 'ro','MarkerSize',8,'MarkerFaceColor','r');

    hold(app.UIAxes, 'on');

    for k = 1:size(data,1)
    xr_k = data{k,3};     % XR column
    yr_k = f(xr_k);
    plot(app.UIAxes, xr_k, yr_k, 'ro','MarkerSize',6,'MarkerFaceColor','r');
    end

    hold(app.UIAxes, 'off');
end

        %% ================= MATRIX =================
        function ComputeMatrix(app)
        
            try
                % Matrix A
                A = eval(strjoin(app.MatrixInput.Value));
            catch
                app.MatrixOutput.Value = "Invalid Matrix A input.";
                return;
            end
        
            op = app.MatrixOpDropDown.Value;
        
            try
                switch op
        
                    case 'Determinant'
                        result = det(A);
        
                    case 'Inverse'
                        result = inv(A);
        
                    case 'Transpose'
                        result = A';
        
                    case 'Power'
                        result = A^2;
        
                    case 'Adjoint'
                        result = det(A)*inv(A); %#ok<MINV>
        
                    case 'Addition (A + B)'

                        B = eval(strjoin(app.MatrixBInput.Value));
                        result = A + B;
        
                    case 'Multiplication (A × B)'

                        B = eval(strjoin(app.MatrixBInput.Value));
                        result = A * B;
        
                    case 'Solve AX = B'

                        B = eval(strjoin(app.MatrixBInput.Value));
                    
                        % check square matrix
                        [r,c] = size(A);
                        if r ~= c
                            error('A must be square for AX = B');
                        end
                    
                        result = A \ B;
        
                    otherwise
                        result = "Operation not implemented.";
                end
        
                app.MatrixOutput.Value = mat2str(result);
        
            catch
                app.MatrixOutput.Value = "Error computing matrix.";
            end
        end
    end

    methods (Access = public)

        function app = numericalmethod

            app.UIFigure = uifigure('Position', [100 100 1100 600], ...
                'Name', 'Numerical Methods PRO App');
            app.TabGroup = uitabgroup(app.UIFigure, ...
                'Position', [10 10 1080 580]);

            %% ROOT TAB
            app.RootTab = uitab(app.TabGroup, 'Title', 'Root Finding');

            app.UITable = uitable(app.RootTab, ...
                'Position', [20 20 600 350]);

            app.UIAxes = uiaxes(app.RootTab, ...
                'Position', [650 100 300 300]);

            % Equation Selection
            uilabel(app.RootTab, 'Text', 'Equation:', 'Position', [20 500 60 20]);
            app.EquationDropDown = uidropdown(app.RootTab, ...
                'Items', {'x^3 - x - 2', 'sin(x) - 0.5', 'exp(x) - 3', 'x^2 - 4', 'cos(x) - x', 'log(x) - 1', 'Custom'}, ...
                'Position', [85 500 150 22], ...
                'ValueChangedFcn', @(src, event) UpdateCustomField(app));

            uilabel(app.RootTab, 'Text', 'Custom Eq:', 'Position', [250 500 70 20]);
            app.CustomEquationField = uieditfield(app.RootTab, 'text', ...
                'Position', [325 500 150 22], ...
                'Placeholder', 'e.g., x^2 - 4', ...
                'Enable', 'off');

            % XL, XU, Method
            uilabel(app.RootTab, 'Text', 'XL', 'Position', [20 420 30 20]);
            app.XLEdit = uieditfield(app.RootTab, 'numeric', ...
                'Position', [50 420 80 22], 'Value', 1);

            uilabel(app.RootTab, 'Text', 'XU', 'Position', [150 420 30 20]);
            app.XUEdit = uieditfield(app.RootTab, 'numeric', ...
                'Position', [180 420 80 22], 'Value', 2);

            uilabel(app.RootTab, 'Text', 'Tol', ...
                'Position', [280 420 30 20]);

            app.ToleranceEdit = uieditfield(app.RootTab, 'numeric', ...
                'Position', [310 420 80 22], ...
                'Value', 0.0001);

            app.MethodDropDown = uidropdown(app.RootTab, ...
                'Items', {'Bisection', 'Regula Falsi', 'Newton Raphson', 'Secant', 'Incremental'}, ...
                'Position', [420 420 150 22]);

            app.ComputeButton = uibutton(app.RootTab, 'push', ...
                'Text', 'Compute', ...
                'Position', [590 420 100 25], ...
                'ButtonPushedFcn', @(btn, event) ComputeRoot(app));

           %% MATRIX TAB 
            app.MatrixTab = uitab(app.TabGroup, 'Title', 'Matrix Operations');
            
            % MAIN LAYOUT PANELS
            inputPanel = uipanel(app.MatrixTab, ...
                'Title', 'Matrix Input', ...
                'Position', [20 320 320 220]);
            
            opPanel = uipanel(app.MatrixTab, ...
                'Title', 'Matrix Operations', ...
                'Position', [360 300 300 240]);
            
            outputPanel = uipanel(app.MatrixTab, ...
                'Title', 'Result', ...
                'Position', [680 150 350 390]);
            
            %% MATRIX A INPUT
            uilabel(inputPanel, 'Text', 'Matrix A:', ...
                'Position', [10 160 80 20]);
            
            app.MatrixInput = uitextarea(inputPanel, ...
                'Position', [10 90 290 70], ...
                'Value', {'[1 2; 3 4]'}, ...
                'FontName', 'Consolas');
            
            %% MATRIX B INPUT (ADD THIS)
            uilabel(inputPanel, 'Text', 'Matrix B:', ...
                'Position', [10 60 80 20]);
            
            app.MatrixBInput = uitextarea(inputPanel, ...
                'Position', [10 10 290 50], ...
                'Value', {'[5 6; 7 8]'}, ...
                'FontName', 'Consolas');

            %% MATRIX OPERATIONS
            app.MatrixOpDropDown = uidropdown(opPanel, ...
                'Items', {'Determinant', 'Inverse', 'Transpose', ...
                          'Adjoint', 'Power', ...
                          'Addition (A + B)', ...
                          'Multiplication (A × B)', ...
                          'Solve AX = B'}, ...
                'Position', [20 160 250 30]);
            
            uilabel(opPanel, ...
                'Text', 'Select Operation:', ...
                'Position', [20 190 200 20], ...
                'FontWeight', 'bold');
            
            app.MatrixButton = uibutton(opPanel, 'push', ...
                'Text', 'Compute Result', ...
                'Position', [20 100 250 40], ...
                'FontWeight', 'bold', ...
                'BackgroundColor', [0.2 0.6 1], ...
                'FontColor', 'white', ...
                'ButtonPushedFcn', @(btn, event) ComputeMatrix(app));
            
            % hint text
            uilabel(opPanel, ...
                'Text', 'Note: For A + B, A × B, AX = B → B will be requested', ...
                'Position', [20 50 260 40], ...
                'FontSize', 10, ...
                'FontColor', [0.4 0.4 0.4]);
            
            %% OUTPUT
            uilabel(outputPanel, 'Text', 'Result:', ...
                'Position', [10 350 80 20]);
            
            app.MatrixOutput = uitextarea(outputPanel, ...
                'Position', [10 20 330 320], ...
                'FontName', 'Consolas', ...
                'Editable', 'off');
           
            uilabel(app.MatrixTab, 'Text', 'Matrix Calculator', ...
                'Position', [20 550 300 30], ...
                'FontSize', 16, ...
                'FontWeight', 'bold');

        function UpdateCustomField(app)
            if strcmp(app.EquationDropDown.Value, 'Custom')
                app.CustomEquationField.Enable = 'on';
            else
                app.CustomEquationField.Enable = 'off';
            end
        end
    end   
end       
end 
