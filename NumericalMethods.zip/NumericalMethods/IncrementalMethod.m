function data = IncrementalMethod(f, xl, tol)

step = 0.1;

i = 1;
data = {};

while true

    xr = xl + step;

    fxl = f(xl);
    fxr = f(xr);

    product = fxl * fxr;

    ea = abs(xr - xl);

    if product < 0
        remarks = 'Root Found';
    else
        remarks = 'Searching';
    end

    data(end+1,:) = ...
    {i, xl, xr, xr, fxl, fxr, ea, product, remarks};

    if ea < tol || product < 0
        break;
    end

    xl = xr;

    i = i + 1;

    if i > 100
        break;
    end
end
end