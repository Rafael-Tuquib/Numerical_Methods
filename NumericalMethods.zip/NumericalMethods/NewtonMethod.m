function data = NewtonMethod(f, df, x0, tol)

i = 1;
xr_old = 0;
data = {};

while true

    xr = x0 - f(x0)/df(x0);

    fxr = f(xr);

    if i == 1
        ea = 0;
    else
        ea = abs((xr - xr_old)/xr) * 100;
    end

    if ea < tol && i > 1
        remarks = 'Converged';
    else
        remarks = 'Iterating';
    end

    data(end+1,:) = ...
    {i, x0, xr, df(x0), f(x0), fxr, ea, f(x0)*fxr, remarks};

    if ea < tol && i > 1
        break;
    end

    xr_old = xr;
    x0 = xr;

    i = i + 1;

    if i > 100
        break;
    end
end
end